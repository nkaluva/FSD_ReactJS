import React from 'react';
import ReactDOM from 'react-dom';
import './styles.css';
//
const Index = () => {
  return <div><h2> Welcome to Skillsoft Live Learning</h2></div>;
};
//
ReactDOM.render(<Index />, document.getElementById('root'));
